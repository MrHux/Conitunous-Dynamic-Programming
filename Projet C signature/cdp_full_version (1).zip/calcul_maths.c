//
//  calcul_maths.c
//  algo
//
//  Created by Charles on 02/06/2014.
//  Copyright (c) 2014 Charles. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "struct.h"


/*
 * calcul du minimum entre deux entiers
 * en entrée : deux entiers x et y
 * en sortie : le minimum.
 */
double min(double x,double y){
    if(x<y)return x;
    else return y;
    
}

/*
 * calcul de la distance entre deux entiers situé dans deux tableaux
 * en entrée : deux tableaux d'entier, i et j la position respective des entiers dans le tableau.
 * en sortie : la distance entre les deux entiers.
 */
double distance(double ** table1, double ** table2 ,int indexTable1, int indexTable2, int nbElement){
    
    double somme = 0 ;
    
    if(table1==NULL || table2==NULL){
        printf("Erreur");
        return -1;
    }
    
    int k = 0; /*permet de parcourir les composante d'un vecteur*/
    
    for(k=0 ; k<nbElement ;k++){
        somme = somme + (double)((table1[k][indexTable1]-table2[k][indexTable2])*(table1[k][indexTable1]-table2[k][indexTable2]));
    }
    
    return sqrt(somme);
}





/*
void afficheliste(listIndex * listeIndex){
 printf("Index :\n");
 listIndex * temp=listeIndex;
 
 while(temp!=NULL){
 
 printf(" %d ,",temp->index);
 
 temp=temp->nxt;
 }
 
 }
 
 
 void afficheMatriceAB(double *table , int sizeHeight//, double ** test , int nbEleVect){
 
 int i;
 //int k;
 
 
 for(i=0 ; i<sizeHeight ; i++){
 printf("\n");
 printf("%d \t", i);
 printf(" %f \t",table[i]);
 //  for(k=0 ; k<nbEleVect ; k++){
 //   printf("%d \t", test[k][i]);
 //   }
 printf("\n");
 }
 
 }
 
 void afficheMatriceA(double *table , int sizeHeight){
 
 int i;
 
 for(i=0 ; i<sizeHeight ; i++){
 printf("\n");
 printf("%d \t", i);
 printf(" %f ",table[i]);
 printf("\n");
 }
 
 }
 
 
 
 void afficheMatrice(double **table , int sizeHeight , int sizeLength){
 
 int j;
 int i;
 
 for(i=0 ; i<sizeHeight ; i++){
 printf("\n");
 for(j=0 ; j<sizeLength; j++){
 printf("\t");
 printf(" %f ",table[i][j]);
 printf("\t");
 }
 printf("\n");
 }
 
 }
 
 
 
 
 void affichetout(double * A, double ** P , int tailletest, int tailleref,int  nbEleVect, double ** test, double ** reference){
 
 printf("\n");
 
 printf("affiche taille ref : %d", tailleref);
 printf("affiche taille test : %d", tailletest);
 //affichage des matrices
 
 printf("\n Affichage des matrices : ");
 
 printf("\n \n Matrice test :");
 afficheMatrice(test,nbEleVect,tailletest);
 
 
 printf("\n \n Matrice reference :");
 afficheMatrice(reference, nbEleVect, tailleref);
 printf("\n \n \n Matrice P :");
 afficheMatrice(P, tailletest+2, tailleref);
 
 printf("\n \n \n Matrice A");
 afficheMatriceA(A,tailletest);
 
 
 }
 
 */

