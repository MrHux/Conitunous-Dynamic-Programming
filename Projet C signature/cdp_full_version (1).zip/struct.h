//
//  struct.h
//  algo
//
//  Created by Charles on 27/05/2014.
//  Copyright (c) 2014 Charles. All rights reserved.
//



#ifndef algo_struct_h
#define algo_struct_h

/* établir la structure des tableaux */

typedef struct TableSize TableSize;
struct TableSize
{
    int nbColonne;
    int nbLigne;
};

typedef struct listIndex{
    int index;
    struct listIndex *nxt;
} listIndex;

double min(double x,double y);

double distance(double ** table1, double ** table2 ,int indexTable1, int indexTable2, int nbElement);

double ** cdp(double ** test , double ** reference, int sizeTest, int sizeRef, int nbEleVect);

double * resultatA(double** matriceP , int sizeTest, int sizeRef , int nbEleVect);

TableSize countFileSize(char * monFichier);

double ** createTable(char * monFichier , int n , int m);

void init_listIndex(listIndex * newIndex);

listIndex * findIndexSubSequence(double * table, int sizeHeight, double seuil);

void resultat(double * A, double ** P, double ** test, double ** ref , int tailleTest, int tailleRef, int nbEleVect, char * fichierResultat, char * fichierMatriceP, double seuil);

void afficheliste(listIndex * listeIndex);

void afficheMatriceAB(double *table , int sizeHeight/*, double ** test , int nbEleVect*/);

void afficheMatriceA(double *table , int sizeHeight);

void afficheMatrice(double **table , int sizeHeight , int sizeLength);

void affichetout(double * A, double ** P , int tailletest, int tailleref,int  nbEleVect, double ** test, double ** reference);


#endif
