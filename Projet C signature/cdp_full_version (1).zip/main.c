#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "struct.h"


int main()
{
/* définition des matrices */

double ** P;
double * A;

/*taille des matrices*/
int nbEleVectRef;
int nbEleVectTest;

int tailleref=0;
int tailletest=0;

/*Fichier de requête*/
char fichierTest []= "/Users/Charles/Documents/test/algo/algo/test.txt";/*petite séquence*/

TableSize dimTest=countFileSize(fichierTest);
tailletest=dimTest.nbColonne;
nbEleVectTest=dimTest.nbLigne;


/*déclaration du pointeur vers le fichier réference*/
double ** test=createTable(fichierTest, tailletest , nbEleVectTest);

/*Séquence de ressource*/
char fichierRef[] = "/Users/Charles/Documents/test/algo/algo/ref.txt";/*grande séquence*/

TableSize dimRef=countFileSize(fichierRef);
tailleref=dimRef.nbColonne;
nbEleVectRef=dimRef.nbLigne;


/*déclaration du pointeur vers le fichier test*/
double ** reference=createTable(fichierRef , tailleref , nbEleVectRef);

int nbEleVect;

if(nbEleVectTest == nbEleVectRef){
    nbEleVect=nbEleVectRef;
}
else{
    printf("Erreur ! Les Fichiers de Référence et de Test ont des vecteurs de longueurs différentes !");
    return 0;
}

/*si les fichier sont vide on affiche une erreur*/
if(test== NULL || reference==NULL){
    printf("test ou ref == NULL");
    return 0;
}
else
{

P=cdp(reference, test, tailleref , tailletest, nbEleVect);

A=resultatA(P, tailleref, tailletest , nbEleVect);


//affichetout(A,P,tailletest,tailleref,nbEleVect ,test,reference);

printf("\n \n rentrer le seuil \n \n");
double seuil = 0;
scanf("%lf", &seuil);

//afficheMatriceAB(A, tailletest);

char fichierResultat []= "/Users/Charles/Documents/test/algo/resultat.txt";
char fichierMatriceP []= "/Users/Charles/Documents/test/algo/matricep.txt";

resultat(A, P, reference, test , tailleref, tailletest, nbEleVect, fichierResultat, fichierMatriceP, seuil);

/*libération des pointeurs*/

free(reference);
free(test);
free(P);
free(A);


}
return 0;
}
